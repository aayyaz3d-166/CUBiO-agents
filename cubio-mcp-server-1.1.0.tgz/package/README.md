# @cubio/mcp-server

> Sovereign 20-Agent Model Context Protocol (MCP) Stdio Server for CUBiO AI

`@cubio/mcp-server` is a standalone, local Model Context Protocol (MCP) server that exposes CUBiO's multi-agent architecture and autonomous engineering workflow to external AI clients such as Claude Desktop, Cursor, Antigravity, and GitHub Copilot.

---

## 1. Safety Invariants

- **Permanent Hardware Actuation Lockout:** `IS_ACTUATION_BLOCKED = true` is permanently active.
- **Strict Stdio Discipline:** `stdout` is reserved exclusively for JSON-RPC 2.0 frames; all diagnostic and logging output is emitted to `stderr`.
- **Zero Production Drift:** Core assets (`data/cubio_studio.db`, `src/core/address369.ts`, `data/checkpoints/phase16_production_final_sealed_1m.3dmemory`) are strictly protected from modification.

---

## 2. Supported Tools (17 Sovereign Tools)

1. **`list_agents`**: Discover all 20 registered CUBiO agents, versions, capabilities, and lifecycle statuses.
2. **`get_agent_capabilities`**: Retrieve declared capabilities, permissions, and input/output schema references for a specific agent ID.
3. **`orchestrate_tasks`**: Dispatch DAG task orchestration requests to the Agent Orchestration Agent (AOA) with dependency resolution and signed results.
4. **`discover_skills`**: Discover registered agent skills by exact skill ID or capability keyword.
5. **`execute_skill`**: Execute a validated agent skill with tamper-evident execution provenance.
6. **`submit_task`**: Single-entry-point natural-language task intake managed by Native PMA. Submit objectives without manually selecting agents or skills. Supports `autoExecute: true` and `workspacePath`.
7. **`get_task_status`**: Query the status, routing state, constraints, and progress of a task.
8. **`execute_task`**: Execute an accepted task through PMA, selecting specialists, delegating through AOA, and recording verifiable results.
9. **`onboard_workspace`**: Authorize and onboard an external repository with automatic language detection, architecture classification, and test discovery.
10. **`inspect_workspace`**: Inspect an authorized workspace and return its discovery profile, entry points, and dynamic subsystems.
11. **`select_workspace`**: Switch active authorized workspace for subsequent task operations.
12. **`list_workspaces`**: Enumerate all authorized workspaces and their active statuses.
13. **`authorize_workspace`**: Explicitly configure workspace boundaries, read-only mode, and write approval policies.
14. **`verify_path_containment`**: Security audit tool detecting traversal attacks, root escapes, symlink/junction escapes, and protected baseline tampering.
15. **`request_write_approval`**: Generate cryptographic HMAC-SHA256 user approval proposals bound to `taskId:relativePath:contentSha256`.
16. **`confirm_write_approval`**: Authenticate human operator with dynamic session secret to confirm and sign write tokens.
17. **`write_workspace_file`**: Secure atomic workspace file modification with token verification and post-write disk readback.

---

## 3. Installation & Local Execution

### From Tarball (Standalone / Air-Gapped)
```bash
# In your target consumer repository or project directory:
npm install /path/to/cubio-mcp-server-1.1.0.tgz
```

### From Standalone Repository / Local Source
```bash
# Install dependencies:
npm install

# Build standalone distribution bundle (from monorepo root or package dir):
npm run build

# Start or test CLI:
node bin/cubio-mcp.js --help
node bin/cubio-mcp.js --version
```

---

## 4. MCP Client Configuration

### Claude Desktop (`claude_desktop_config.json`)
```json
{
  "mcpServers": {
    "cubio": {
      "command": "node",
      "args": ["<path-to-cubio-mcp>/bin/cubio-mcp.js", "--workspace", "/path/to/your/project"]
    }
  }
}
```

### Cursor (`.cursor/mcp.json`)
```json
{
  "mcpServers": {
    "cubio": {
      "command": "node",
      "args": ["<path-to-cubio-mcp>/bin/cubio-mcp.js", "--workspace", "${workspaceFolder}"]
    }
  }
}
```

---

## 5. Security Architecture & Operator Secret Provisioning

### 5.1 Human Operator Credential Provisioning
Write operations into authorized workspaces require two-step cryptographic approval. Autonomous agents are strictly prohibited from approving their own write proposals.

To enable write authorization, provision a server-side operator secret via host environment variable:
```bash
# Set in host environment (never commit real secrets to configuration files or git):
export CUBIO_HUMAN_OPERATOR_SECRET="your-strong-random-operator-key-min-16-chars"
# Alternatively:
export CUBIO_HUMAN_OPERATOR_KEY="your-strong-random-operator-key-min-16-chars"
```

If no environment variable is provided, CUBiO defaults to generating an unguessable ephemeral 256-bit random secret in memory. Because this secret is never printed or exposed, all write confirmation attempts fail closed until an operator key is explicitly configured.

### 5.2 Two-Step Governed Write Lifecycle
1. **Proposal (`request_write_approval`):** Agent submits target relative path and proposed content. Server returns a proposal record (`PROP-...`) and content SHA-256 hash. No active write token is issued.
2. **Human Confirmation (`confirm_write_approval`):** The human operator provides `operatorId` and `operatorAuthKey`.
   - Any agent identifier (e.g. `AGENT-008-AOA`, `PMA`, `CDA`) is rejected immediately with `AGENT_SELF_APPROVAL_DETECTED`.
   - Credentials are verified using timing-safe comparison (`crypto.timingSafeEqual`).
   - Upon verification, an ephemeral, single-use, workspace-and-content-bound approval token (`AUTH-...`) is minted.
3. **Write Execution (`write_workspace_file`):** Agent submits the write request with `approvalToken`. The server validates path containment, checks token validity, atomically writes to disk, verifies post-write readback SHA-256, and immediately consumes the token. Replaying a token fails closed with `TOKEN_ALREADY_USED`.

### 5.3 Secret Redaction & Environment Isolation
- **Subprocess Environment Isolation:** Subprocesses spawned by the Code Execution Agent (CEA) receive a sanitized environment containing only `PATH`, `SYSTEMROOT`, `TEMP`, `TMP`, and `NODE_ENV`. Host credentials and `CUBIO_HUMAN_OPERATOR_SECRET` are never exposed to child execution contexts.
- **Universal Redaction (`SecretRedactor`):** All JSON-RPC responses, tool diagnostics, and stderr error logs pass through `SecretRedactor`. Key-value representations (`operatorAuthKey: "..."`, `CUBIO_HUMAN_OPERATOR_SECRET=...`) and registered raw secret values are masked unconditionally with `[REDACTED_API_KEY]`, `[REDACTED_SECRET]`, or `[REDACTED_OPERATOR_SECRET]`.

### 5.4 Rotation & Revocation
- **Rotation:** Calling `rotateHumanOperatorSecret(newSecret)` updates the active credential and immediately invalidates all previously minted tokens and pending proposals.
- **Revocation:** Calling `revokeHumanOperatorSecret()` replaces the credential with an unguessable ephemeral key and purges all active tokens, failing closed to read-only until reprovisioned.

---

## 6. License

Apache-2.0 © CUBiO AI Engineering Team
